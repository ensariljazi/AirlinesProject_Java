package com.example.demo;

public class TicketNumberExeption extends Exception {
}
