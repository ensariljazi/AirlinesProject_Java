package com.example.demo.service;

public interface FlightSpendsService {
    double sumOfSpends();

}
